library(tidyverse)
library(dados)

# 1. 
# 2. 