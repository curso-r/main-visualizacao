library(tidyverse)
library(dados)

# Leia o capítulo e faça os exercícios do nosso livro!
## https://livro.curso-r.com/8-1-o-pacote-ggplot2.html#exerc%C3%ADcios-22

# Obs: se você tiver baixado o material.zip, a base IMDB pode ser lida rodando
imdb <- readr::read_rds("dados/imdb.rds")
