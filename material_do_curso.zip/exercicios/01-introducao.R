library(tidyverse)
library(dados)

# Leia o capítulo e faça os exercícios do curso de R para Ciência de Dados I.
## https://livro.curso-r.com/8-1-o-pacote-ggplot2.html

# Obs: a base imdb pode ser lida rodando
imdb <- readr::read_rds("https://github.com/curso-r/blog/raw/main/static/data/desafios/imdb.rds")
