library(tidyverse)
library(dados)

# Esta aula não tem exemplos de aula fixos, apenas atividades práticas,
# que são disponibilizadas ao final de cada aula na página do curso ;)